x=input("Enter number: ")

if(x==x[::-1]):
        print("number is palindrome")
else:
        print("number is not palindrome")
        
        
